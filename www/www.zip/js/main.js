//////////////////////////////
////Home Page main.js
//////////////////////////////
var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' };
var options2 = { year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' };
var options3 = { year: 'numeric', month: 'numeric', day: 'numeric'};
var options4 = { hour: 'numeric', minute: 'numeric', second: 'numeric' };
//global variables
var name_selected;
var cameras;


var socket = io();
socket.on('newEvent', function(msg) {
    console.log('receiving event')
 	buildTable(msg)
});
socket.on('directory', function(msg) {
    console.log('receiving directory')
 	buildNames(msg)
});
socket.on('getCameras', function(msg) {
    console.log('receiving cameras')
    buildCameras(msg)
});
socket.on('queryResult', function(msg) {
    console.log('receiving report')
    console.log(msg)
    buildReport(msg)
});


function incidents(){

	$(".nav-item").click(function(e) {
    	console.log(this);

    	$(this).addClass("active").siblings().removeClass("active");
    })
    var dir = document.getElementById('reports');
    dir.classList.add("hidden")
    var dir = document.getElementById('directory');
    dir.classList.add("hidden")
    var inc = document.getElementById('incidents');
    inc.classList.remove("hidden")
}
function directory(){

	$(".nav-item").click(function(e) {
    	console.log(this);
    	$(this).addClass("active").siblings().removeClass("active");
    })

    var dir = document.getElementById('directory');
    dir.classList.remove("hidden")
    var inc = document.getElementById('incidents');
    inc.classList.add("hidden")
    var dir = document.getElementById('reports');
    dir.classList.add("hidden")
    socket.emit('getDirectory',null)

}
function report(){

    $(".nav-item").click(function(e) {
        console.log(this);
        $(this).addClass("active").siblings().removeClass("active");
    })
    var dir = document.getElementById('reports');
    dir.classList.remove("hidden")
    var inc = document.getElementById('incidents');
    inc.classList.add("hidden")
    var inc = document.getElementById('directory');
    inc.classList.add("hidden")

}

function buildCameras(msg){
    var json = JSON.parse(msg);
    console.log(json);
    var cam_select = document.getElementById('cam_select');
    console.log(cam_select);
       var len = json.data.length;
       console.log(len);
       for (var i = 0; i<len ; i++)
          {
            console.log('inserting',json.data[i].name,json.data[i].id);
            cam_select.options[json.data[i].id] = new Option(json.data[i].name,json.data[i].id);
          }

}

function buildNames(json){
  var table = ''
  var options = '<option selected value="">Select</option>'
 for(var i=0; i< json.length; i++){
 	table += '<tr class="table-row-names clickable-row " >'
 	table += '<th hidden="true" scope="row" id="id">'+json[i].id+'</th>';
 	table += '<td id="Fullname" min-width="100px" >'+json[i].person_name+'</td>'
 	table += '<td id="email" width="200px" >'+json[i].email_address+'</td>'
 	table += '<td id="phone" >'+json[i].phone_number+'</td>'
 	table += '<td id="title">'+json[i].title+'</td>'
 	table += '</tr>'

 	options += `<option value="${json[i].email_address}">${json[i].title} ${json[i].person_name} (${json[i].email_address})</option>`


 }
 try{
	const regex = /null/ig;
	table = table.replace(regex, '');
	options = options.replace(regex, '');

 	var rows = document.getElementById('rowsnames');
	rows.innerHTML = table;

	var rows = document.getElementById('to');
	rows.innerHTML = options;


	rows.classList.add('tbody')
	}
	catch(e){document.getElementById('test').innerHTML = 'Error 123:'+e}

$(document).ready(function($) {

     $(".table-row-names").click(function(e) {
    	console.log(this);

    	$(this).addClass("table-selected").siblings().removeClass("table-selected");
		//$('.table-selected td').addClass("table-selected")

        var id =  $(this).find("th#" + 'id').html()
    	console.log(id)
    	name_selected = id;
    });

});

}

/*
$(document).ready(function(){
  $('.dropdown-toggle').on("click", function(e){
   
    $(this).next('div').addClass('show');
    e.stopPropagation();
    e.preventDefault();
  });
});*/

/*
let dropdowns = document.querySelectorAll('.dropdown-toggle')
dropdowns.forEach((dd)=>{
    dd.addEventListener('click', function (e) {
        var el = this.nextElementSibling
        el.style.display = el.style.display==='block'?'none':'block'
    })
})
*/
/*
$('.dropdown-submenu').hover(function(){ 
  $('.dropdown-toggle', this).trigger('click'); 
});
*/


function  btnBackReport(event){

    var dir = document.getElementById('tablereports');
    dir.classList.add("hidden")
    var inc = document.getElementById('formreports');
    inc.classList.remove("hidden")

};

function buildReport(json)
{
    var dir = document.getElementById('tablereports');
    dir.classList.remove("hidden")
    var inc = document.getElementById('formreports');
    inc.classList.add("hidden")


    var title = document.getElementById('resultsTitle');
    title.innerHTML = '<button class="btn btn-success search-btn btn-directory" onclick="btnBackReport(event)">'
                    + '<i class="fa fa-backward" id="backReport" aria-hidden="true"></i></button>' + ' '+ json.length + ' Results' 
    
    var table = ''
    for(var i=0; i< json.length; i++){
            table += '<tr class="table-row clickable-row " >'
            table += '<th hidden="true" scope="row" id="id">'+json[i].id+'</th>';
            table += '<td id="camera_id" >'+json[i].camera_id+'</td>'
            table += '<td id="incident" >'+json[i].incident+'</td>'
            table += '<td id="time" >'+new Date(json[i].time).toLocaleDateString("en-US", options)+'</td>'
            table += '<td id="state">'+json[i].state || ''+'</td>'
            table += '<td id="operator">'+json[i].operator+'</td>'
            if(json[i].response_time == null)
                table += '<td id="responsetime"></td>'
            else
                table += '<td id="responsetime">'+new Date(json[i].response_time).toLocaleDateString("en-US", options2)+'</td>'
            if(json[i].resolution_time == null)
                table += '<td id="resolution_time"></td>'
            else
                table += '<td id="resolution_time">'+new Date(json[i].resolution_time).toLocaleDateString("en-US", options2)+'</td>'
            table += '<td hidden="true" id="comment">'+json[i].comment+'</td>';
            table += '<td hidden="true" id="action">'+json[i].action+'</td>';
            table += '<td hidden="true" id="priority">'+json[i].priority+'</td>';
            table += '<td hidden="true" id="procedure">'+json[i].procedure+'</td>';
            table += '</tr>'
    } 
    try
    {
        const regex = /null/ig;
        table = table.replace(regex, '');
        
        var rows = document.getElementById('rowsResults');
        rows.innerHTML = table;
        rows.classList.add('tbody')
    }
    catch(e){document.getElementById('test').innerHTML = "Error 221: " +e
    }


}   
var tabindex=1;


function buildTable(json)
{
console.log("buildTable")

var cam_select = document.getElementById('cam_select');

console.log(cam_select[18].innerHTML)
console.log('CAMARA: ',$('#cam_select').val())

  var table = ''
 for(var i=0; i< json.length; i++){



 	table += '<tr class="table-row clickable-row" tabindex="'+json[i].id+'">'
 	table += '<td scope="row" width="100px" id="id">'+json[i].id+'</th>';
 	table += '<td id="camera_id" >'+cam_select[json[i].camera_id].innerHTML+'</td>'
 	table += '<td id="incident" >'+json[i].incident+'</td>'
 	table += '<td id="time" >'+new Date(json[i].time).toLocaleDateString("en-US", options2)+'</td>'
 	table += '<td id="state">'+json[i].state || ''+'</td>'
 	table += '<td id="operator">'+json[i].operator+'</td>'
 	if(json[i].response_time == null)
 		table += '<td id="responsetime"></td>'
 	else
 		table += '<td id="responsetime">'+new Date(json[i].response_time).toLocaleDateString("en-US", options2)+'</td>'
 	if(json[i].resolution_time == null)
 		table += '<td id="resolution_time"></td>'
 	else
 		table += '<td id="resolution_time">'+new Date(json[i].resolution_time).toLocaleDateString("en-US", options2)+'</td>'
 	table += '<td hidden="true" id="comment">'+json[i].comment+'</td>';
 	table += '<td hidden="true" id="action">'+json[i].action+'</td>';
	table += '<td hidden="true" id="priority">'+json[i].priority+'</td>';
	table += '<td hidden="true" id="procedure">'+json[i].procedure+'</td>';

 	table += '</tr>'
  }

try
{
const regex = /null/ig;
table = table.replace(regex, '');
var rows = document.getElementById('rows');
rows.innerHTML = table;
rows.classList.add('tbody');
filter();
}


catch(e){document.getElementById('test').innerHTML = "Error 276: "+ e
}


$(document).ready(function($) {
  $('.dropdown-toggle').dropdown();

    $(".table-row").click(function(e) {
    	console.log(this);

    	$(this).addClass("table-selected").siblings().removeClass("table-selected");
		//$('.table-selected td').addClass("table-selected")

        var id =  $(this).find("td#" + 'id').html()
        var incidentTime =  $(this).find("td#" + 'time').html()
        var camera = $(this).find("td#" + 'camera_id').html()
        var priority = $(this).find("td#" + 'priority').html()
        var state = $(this).find("td#" + 'state').html()
        var comment = $(this).find("td#" + 'comment').html()
        var location = $(this).find("td#" + 'location').html()
		
		var title  =  document.getElementById('card_title')
		var d  =  document.getElementById('card_incidentDate')
        var t  =  document.getElementById('card_incidentTime')
        var c  =  document.getElementById('card_camera').innerHTML=camera;  
        var p  =  document.getElementById('card_priority').innerHTML=priority;  
        var l  =  document.getElementById('card_location').innerHTML='';
        var s  =  document.getElementById('card_state').innerHTML=state;  
        var co = document.getElementById('card_comment').value=comment;  
        
        title.innerHTML	 = id;
        d.innerHTML=new Date(incidentTime).toLocaleDateString("en-US", options3);
        t.innerHTML=new Date(incidentTime).toLocaleTimeString("en-US", options4);
        c.innerHTML=camera	;
        p.innerHTML=priority;
        s.innerHTML=state;
        co.value=comment;
        tabindex=id;

		var rows = document.getElementById('incidentCard');
		var table = document.getElementById('tablediv');
        var filters = document.getElementById('tablediv');var table = document.getElementById('tablediv');

		 if (rows.classList.contains("hidden")) {
    				rows.classList.remove("hidden");
    				table.classList.replace('col-md-12','col-md-9')
    				table.classList.add('tablediv')

    	 }

    });

    $("tr[tabindex=" + tabindex + "]").addClass("table-selected").siblings().removeClass("table-selected"); 
    $("tr[tabindex=" + tabindex + "]").focus();
    

});
}   

function btnDir(e)
{
    e.preventDefault();
    var form = document.getElementById('newuser');  
        var user =  new FormData(form)
        var newuser = {}
        newuser.person_name =form.fullname.value
        newuser.email_address = form.email.value
        newuser.phone_number = form.phone.value
        newuser.title = form.title.value

        if(newuser.person_name == '' || newuser.email_address == ''){

            //verification
        }
        else{
              console.log('ok')        
               socket.emit('newuser',newuser);
        }
}


$(".closeCard").click(function(e) {
     	var rows = document.getElementById('incidentCard');
		var table = document.getElementById('tablediv');

     	 if (!rows.classList.contains("hidden")) {
    				rows.classList.add("hidden");
    				table.classList.replace('col-md-9','col-md-12')


    	 }
});

$(".closeCardTransfer").click(function(e) {
     	var rows = document.getElementById('transferCard');
		var incidents = document.getElementById('incidentCards');

     	 if (!rows.classList.contains("hidden")) {
    				rows.classList.add("hidden");
       	 }
       	 if (incidents.classList.contains("hidden")) {
    				incidents.classList.remove("hidden");
       	 }
});

$(".dropdown-item").click(function(e){
			var action = e.currentTarget.innerHTML;
			switch(action){
				case 'Transfer':
					transfer()
				break;
				case 'In Progress':
					 state('In Progress');
				break;
				case 'Resolved':
					 state('Resolved');
				break;
				case 'Closed':
					 state('Closed');
				break;
				case 'False Alarm':
					 state('False Alarm');
				break;
                case 'Low Priority':
                     priority('Low');
                break;
                case 'Medium Priority':
                     priority('Medium');
                break;
                case 'High Priority':
                     priority('High');
                break;
                case 'Started monitoring the incident':
                     procedure('Started monitoring the incident');
                break;
			}
		})

$(function () {
  $("#datepicker").datepicker({ 
        autoclose: true, 
        todayHighlight: true
  }).datepicker('update', new Date());
});


function transfer()
{
	var incidents = document.getElementById('incidentCards');
	var transfer = document.getElementById('transferCard');
    if (transfer.classList.contains("hidden")) {
    		transfer.classList.remove("hidden");
    }
    if (!incidents.classList.contains("hidden")) {
    		incidents.classList.add("hidden");
    }

}

function send_transfer(){

	
	var id  =  document.getElementById('card_title').innerHTML;
	var email = document.getElementById('to').value;
	var time = '';
	if (document.getElementById('t1').checked) {
  		time = document.getElementById('t1').value;
	}
	if (document.getElementById('t2').checked) {
  		time = document.getElementById('t2').value;
	}
	if (document.getElementById('t3').checked) {
  		time = document.getElementById('t3').value;
	}

	var json = {'id':id,'email':email,'time':time}
   	socket.emit('transfer',json)

	console.log(json)
}

function deleteUser()
{

	var id  =  name_selected;
	socket.emit('deleteUser',id);
}

function state(state)
{
	var isoDateTime = new Date();
    var localDate = dateYYYYMMDD(isoDateTime);
    var localTime = isoDateTime.toLocaleTimeString('us',{hour: '2-digit', minute: '2-digit', second: '2-digit',mili: '2-digit', hour12: false});
 	var localTime = localTime +'.'+ isoDateTime.getMilliseconds();
 	var localtimeString = localDate + ' ' + localTime;

	var id  =  document.getElementById('card_title').innerHTML;
	var co =   document.getElementById('card_comment').value; 

	var json = {"id":id,
				"state":state,
				"response_time":localtimeString,
				"operator": operator || 'External User',
				"comment":co
			    };
	console.log('json',json)			    
	if(state == 'Resolved' || state == 'Closed')
	{
	 	json.resolution_time = localtimeString;		    
	}

	if(state == 'False Alarm')
	{
		json.resolution_time = localtimeString;	
		json.comment += '\nFalse Alarm'
	}

	console.log(json)				
	socket.emit('state',json)
}

function priority(priority)
{
    var isoDateTime = new Date();
    var localDate = dateYYYYMMDD(isoDateTime);
    var localTime = isoDateTime.toLocaleTimeString('us',{hour: '2-digit', minute: '2-digit', second: '2-digit',mili: '2-digit', hour12: false});
    var localTime = localTime +'.'+ isoDateTime.getMilliseconds();
    var localtimeString = localDate + ' ' + localTime;

    var id  =  document.getElementById('card_title').innerHTML;
    var co =   document.getElementById('card_comment').value; 

    var json = {"id":id,
                "priority":priority,
                "response_time":localtimeString,
                "operator": operator || 'External User',
                "comment":co
                };
  
    socket.emit('state',json)
}

function procedure(procedure)
{
    var isoDateTime = new Date();
    var localDate = dateYYYYMMDD(isoDateTime);
    var localTime = isoDateTime.toLocaleTimeString('us',{hour: '2-digit', minute: '2-digit', second: '2-digit',mili: '2-digit', hour12: false});
    var localTime = localTime +'.'+ isoDateTime.getMilliseconds();
    var localtimeString = localDate + ' ' + localTime;

    var id  =  document.getElementById('card_title').innerHTML;
    var co =   document.getElementById('card_comment').value; 

    var json = {"id":id,
                "procedure":procedure,
                "response_time":localtimeString,
                "operator": operator || 'External User',
                "comment":co + '\n' + procedure
                };
  
    socket.emit('state',json)
}

function reports(event){

        var incident_select = document.getElementById('incidents-list');
        incident_select = incident_select.options[incident_select.selectedIndex].value;
        //usuario
        var state_select = document.getElementById('state-list');
        state_select = state_select.options[state_select.selectedIndex].text;
        // id de reconocedores
        var cam_selected = []; 
        var cam_select = document.getElementById('cam_select');
        for(var i = 0; i <cam_select.options.length ;i++ )
            {
              if(cam_select.options[i].selected)
               {
                
                cam_selected.push(cam_select.options[i].value);
               }
            }
        var date = document.getElementById('reservationtime').value ;  
        var arrayDefechas = date.split(' - ');
        var date1=arrayDefechas[0];
        var date2=arrayDefechas[1];

        var db = {incident:incident_select,
                  state: state_select,
                  dates: {initial:date1,final:date2},
                  cameras: cam_selected
                 }  
                 socket.emit('query',db)
                 console.log(db)
}





//SecurOS integration, only work when the front Ends is used into SecurOS Desktop
var operator;
 var Media_client;
 starSecurOS()
 function starSecurOS(){
 try{	
 ISScustomAPI.onSetup(function(settings){
			
            let jsonSettings = JSON.parse(settings);
            document.getElementById('test').innerHTML = jsonSettings.operator
            //document.getElementById("test").innerHTML =JSON.stringify(jsonSettings);
            Media_client= jsonSettings.media_client_id;
            operator = jsonSettings.operator ;
             var advance 
            advance = jsonSettings.advanced;
            advance =  JSON.parse(advance);
           // document.getElementById("test").innerHTML =advance.config;
            try{
           
           

            if(advance.config == true)
            	{
            		// document.getElementById("setup").style.display = "inline";
            	}
            }
            catch(e)
            {
					//document.getElementById("test").innerHTML = e;
            }
            
            //document.getElementById("test").innerHTML =Media_client;
        });

}
catch(e)
{}
}

function play()
 {
 	try{   
 	var cam_id  =  document.getElementById('card_camera').innerHTML;
 	console.log(cam_id);
 	var date = document.getElementById('card_incidentDate').innerHTML
    var time  =  document.getElementById('card_incidentTime').innerHTML
    var isoDateTime = new Date(date + ' '+ time);
    var localDate = dateToDDMMYY(isoDateTime);
    var localTime = isoDateTime.toLocaleTimeString('us',{hour: '2-digit', minute: '2-digit', second: '2-digit',mili: '2-digit', hour12: false});
 			var localTime = localTime +':'+ isoDateTime.getMilliseconds();
 			var localtimeString = localDate + ' ' + localTime;
 			document.getElementById("test").innerHTML = Media_client;
 			ISScustomAPI.sendReact("MEDIA_CLIENT", Media_client,"ADD_SEQUENCE",'{"mode":"1x1","seq":"'+cam_id+'"}')  
 			ISScustomAPI.sendReact("MEDIA_CLIENT", Media_client,"SEEK",'{"date":"'+localDate+'","time":"'+localTime+'","cam":"'+cam_id+'"}')  
 			}
 	catch(e){
 		document.getElementById("test").innerHTML =e;		
 	}
   
 };
 function live()
 {
 	try{   
 	var cam_id  =  document.getElementById('card_camera').innerHTML;
 	console.log(cam_id);
 	var date = document.getElementById('card_incidentDate').innerHTML
    		ISScustomAPI.sendReact("MEDIA_CLIENT", Media_client,"ADD_SEQUENCE",'{"mode":"1x1","seq":"'+cam_id+'"}')  
 			}
 	catch(e){
 		document.getElementById("test").innerHTML =e;		
 	}
   
 };

 function dateToDDMMYY(date) {
    var d = date.getDate();
    var m = date.getMonth() + 1; //Month from 0 to 11
    var y = date.getYear()-100;
    return (d <= 9 ? '0' + d : d) + '-' + (m<=9 ? '0' + m : m) + '-' + y;
}

function dateYYYYMMDD(date) {
    var d = date.getDate();
    var m = date.getMonth() + 1; //Month from 0 to 11
    var y = date.getFullYear();
    return (y + '-' + (m<=9 ? '0' + m : m) + '-' + (d <= 9 ? '0' + d : d)) ;
}

////////// end securOS section //////////////////////

var filtername  =''
var filterincident=''
var filterstate=''

function filterByName() {
  var input;
  input = document.getElementById("filterbyname");
  filtername = input.value.toUpperCase();
  filter();
}
  

function filterByIncident(obj) {
  var input;
  filterincident = obj.value;
  if(filterincident=='All')
    filterincident='';
    filter()
}

function filterByState(obj) {
  var input;
  filterstate = obj.value;
  if(filterstate=='All')
    filterstate='';
    filter()
}


function filter()
{
    try{
var f1=true
var f2=true
var f3=true 
var td1,td2,td3
activeIncidents = 0 ;
  table = document.getElementById("table");
  console.log(filtername,filterincident,filterstate)   //2 Y ARMED
  tr = table.getElementsByTagName("tr");
  for (i = 1; i < tr.length; i++) {
    
    td1 = tr[i].getElementsByTagName("td")[1];   //Camera Name
    td2 = tr[i].getElementsByTagName("td")[9];   //Type of Incident
    td3 = tr[i].getElementsByTagName("td")[4];   //State

    if (td1 &&  filtername!=""){
        console.log('filtername')
      txtValue = td1.textContent || td1.innerText; //2
      f1 =  txtValue.toUpperCase().indexOf(filtername) > -1
    }
    else f1=true;

    if (td2 &&  filterincident!="") {
        console.log('filterincident')
      txtValue = td2.textContent || td2.innerText; 
      f2 =  txtValue.toUpperCase() == filterincident.toUpperCase()
    }else f2=true

    if (td3 && filterstate!="") {
        console.log('filterstate')
      txtValue = td3.textContent || td3.innerText; 
      f3  =  txtValue.toUpperCase() == filterstate.toUpperCase()
    }else f3=true

      if (f1 && f2 && f3 && td3) {
        txtValue = td3.textContent || td3.innerText; 
        if(txtValue =='New' || txtValue == 'In Progress')
            activeIncidents++;
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }

    }

console.log(activeIncidents)
      active = document.getElementById("activeIncidents");
      active.innerHTML = '<i class="fa fa-exclamation-triangle triangle" aria-hidden="true"></i> '+activeIncidents+ ' Active Incidents'  ;
 }

catch(e){console.log(e)}

}

